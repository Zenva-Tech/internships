import os
from tkinter import *
import random,os,tempfile,smtplib
from tkinter import messagebox
#funtionality part

def clear():
    bathsoapEntry.insert(0,0)
    facecreamEntry.insert(0,0)
    facewashEntry.insert(0,0)
    hairsprayEntry.insert(0,0)
    hairgelEntry.insert(0,0)
    bodylotionEntry.insert(0,0)
    
    riceEntry.insert(0,0) 
    oilEntry.insert(0,0)
    garriEntry.insert(0,0)
    wheatEntry.insert(0,0)
    yamEntry.insert(0,0)
    sugarEntry.insert(0,0)
    
    topEntry.insert(0,0)
    pepsiEntry.insert(0,0)
    spritEntry.insert(0,0)
    castelEntry.insert(0,0)
    whiskyEntry.insert(0,0)
    milkEntry.insert(0,0)
    
    
def send_email():
    try:
        ob=smtplib.SMTP('smtp.gmail.com',587)
        ob.starttls()
        ob.login(senderEntry.get(),passwordEntry.get())
        Message=textarea.get(1.0,END)
        ob.sendmail(senderEntry.get(),recieverEntry.get(),Message)
        ob.quit()
        messagebox.showinfo('Success','bill Is successfully sent',parent=root1)
    except:
        messagebox.showerror('Error','Something went wrong, Please try again',parent=root1)
    #if textarea.get(1.0,END)=='\n':
    #    messagebox.showerror('Error', 'Bill Is Empty')
    #else:
    root1=Toplevel()
    root1.title('send gmail')
    root1.config(bg='gray20')
    root1.resizable(0,0)
    
    senderFrame=LabelFrame(root1,text='SENDER',font=('arial',16,'bold'), bd=6, bg='gray20',fg='white')
    senderFrame.grid(row=0,column=0,padx=40,pady=20)
    
    senderLabel=Label(senderFrame,text="Sender's Email",font=('arial',14,'bold'), bd=6, bg='gray20',fg='white')
    senderLabel.grid(row=0,column=0,padx=10,pady=8)
    
    senderEntry=Entry(senderFrame,font=('arial',14,'bold'),bd=2,width=23,relief=RIDGE)
    senderEntry.grid(row=0,column=1,padx=10,pady=8)
    
    passwordLabel=Label(senderFrame,text="Password",font=('arial',14,'bold'), bd=6, bg='gray20',fg='white')
    passwordLabel.grid(row=1,column=0,padx=10,pady=8)
    
    passwordEntry=Entry(senderFrame,font=('arial',14,'bold'),bd=2,width=23,relief=RIDGE,show='*')
    passwordEntry.grid(row=1,column=1,padx=10,pady=8)
    
    recipientFrame=LabelFrame(root1,text='RECIPIENT',font=('arial',16,'bold'), bd=6, bg='gray20',fg='white')
    recipientFrame.grid(row=1,column=0,padx=40,pady=20)
    
    
    recieverLabel=Label(recipientFrame,text="Email Address",font=('arial',14,'bold'), bd=6, bg='gray20',fg='white')
    recieverLabel.grid(row=0,column=0,padx=10,pady=8)
    
    recieverEntry=Entry(recipientFrame,font=('arial',14,'bold'),bd=2,width=23,relief=RIDGE)
    recieverEntry.grid(row=0,column=1,padx=10,pady=8)
    
    messageLabel=Label(recipientFrame,text="Message",font=('arial',14,'bold'), bd=6, bg='gray20',fg='white')
    messageLabel.grid(row=1,column=0,padx=10,pady=8)
    
    email_textarea=Text(recipientFrame,font=('arial',14,'bold'), bd=2,relief=SUNKEN,
                        width=42,height=11)
    email_textarea.grid(row=2,column=0,columnspan=2)
    email_textarea.delete(1.0,END)
    email_textarea.insert(END,textarea.get(1.0,END))
    
    sendButton=Button(root1,text='SEND', font=('arial',13,'bold'),width=14)
    sendButton.grid(row=2,column=0,pady=20)
    
    
    gmailIdLabel=Label(senderFrame,text="sender's Email",font=('arial',14,'bold'),bg='gray20',fg='white')
    gmailIdLabel.grid(row=0,column=0)
    root1.mainloop()
    

def print_bill():
    if textarea.get(1.0,END)=='\n':
        messagebox.showerror('Error', 'Bill Is Empty')
    else:
        file=tempfile.mktemp('.txt')
        open(file, 'w').write(textarea.get(1.0,END))
        os.startfile(file,'print')
                             
    

def search_bill():
    for i in os.listdir('bills/'):
        if i.split('.')[0] == billnumberEntry.get():
            f = open(f'bills/{i}', 'r')
            textarea.delete('1.0', END)
            for data in f:
                textarea.insert(END, data)
            f.close()
            break
    else:
        messagebox.showerror('Error','Invalid Bill Number')

def search_bill():
    for i in os.listdir('bills/'):
        print(i)

if not os.path.exists('bills'):
    os.mkdir('bills')

def save_bill():
    global billnumber
    result=messagebox.askyesno('Confirm','Do you want to save the bill?')
    if result:
        bill_content=textarea.get(1.0,END)
        file=open(f'bills/ {billnumber}.txt','w')
        file.write(bill_content)
        file.close()
        messagebox.showinfo('Success',f'bill number{billnumber} is saved successfully')
        billnumber = random.randint(500,1000)

billnumber=random.randint(500,1000)

def bill_area():
    if nameEntry.get==''or phoneEntry.get()=='':
        messagebox.showerror('Error','Customer Details Are Required')
    elif cosmeticpriceEntry.get()==''and grocerypriceEntry.get()==''and drinkspriceEntry.get()=='':
        messagebox.showerror('Error','No Products are selected')
    elif cosmeticpriceEntry.get()=='0 Rs' and grocerypriceEntry.get()=='0 Rs' and drinkspriceEntry.get()=='0 Rs':
        messagebox.showerror('Error','No Products are selected')
        
    textarea.delete(1.0,END)
    
    
    textarea.insert(END,'\t\t**Welcome Customer**\n')
    textarea.insert(END, f'\nBill Number: {billnumber}\n')
    textarea.insert(END, f'\nCustomer Name: {nameEntry.get()}\n')
    textarea.insert(END, f'\nCustomer Phone Number: {phoneEntry.get()}\n')
    textarea.insert(END,'\n=======================================================')
    textarea.insert(END,'Product\t\t\tQuantity\t\t\tPrice')  
    textarea.insert(END,'\n=======================================================')
    if bathsoapEntry.get()!='0':
        textarea.insert(END, f'\nBath Soap\t\t\t{bathsoapEntry.get()}\t\t\t{soapprice} Rs')
    if hairsprayEntry.get()!='0':
        textarea.insert(END, f'\nHair Spray\t\t\t{hairsprayEntry.get()}\t\t\t{hairsprayprice} Rs')
    if hairgelEntry.get()!='0':
        textarea.insert(END, f'\nHair Gel\t\t\t{hairgelEntry.get()}\t\t\t{hairgelprice} Rs')
    if facecreamEntry.get()!='0':
        textarea.insert(END, f'\nFace Cream\t\t\t{facecreamEntry.get()}\t\t\t{facecreamprice} Rs')
    if facewashEntry.get()!='0':
        textarea.insert(END, f'\nFace Wash\t\t\t{facewashEntry.get()}\t\t\t{facewashprice} Rs')
    if bodylotionEntry.get()!='0':
        textarea.insert(END, f'\nBody Lotion\t\t\t{bodylotionEntry.get()}\t\t\t{bodylotionprice} Rs')
    if riceEntry.get()!='0':
        textarea.insert(END, f'\nRice\t\t\t{riceEntry.get()}\t\t\t{riceprice} Rs')
    if oilEntry.get()!='0':
        textarea.insert(END, f'\nOil\t\t\t{oilEntry.get()}\t\t\t{oilprice} Rs')
    if garriEntry.get()!='0':
        textarea.insert(END, f'\nGarri\t\t\t{garriEntry.get()}\t\t\t{garriprice} Rs')
    if wheatEntry.get()!='0':
        textarea.insert(END, f'\nWheat\t\t\t{wheatEntry.get()}\t\t\t{wheatprice} Rs')
    if yamEntry.get()!='0':
        textarea.insert(END, f'\nYam\t\t\t{wheatEntry.get()}\t\t\t{yamprice} Rs')
        
        
    if sugarEntry.get()!='0':
        textarea.insert(END, f'\nSugar\t\t\t{sugarEntry.get()}\t\t\t{sugarprice} Rs')
        
    if topEntry.get()!='0':
        textarea.insert(END, f'\nTop\t\t\t{topEntry.get()}\t\t\t{topprice} Rs')
    if pepsiEntry.get()!='0':
        textarea.insert(END, f'\nPepsi\t\t\t{pepsiEntry.get()}\t\t\t{pepsiprice} Rs')
    if spritEntry.get()!='0':
        textarea.insert(END, f'\nSprit\t\t\t{spritEntry.get()}\t\t\t{pepsiprice} Rs')
    if castelEntry.get()!='0':
        textarea.insert(END, f'\nCastel\t\t\t{castelEntry.get()}\t\t\t{castelprice} Rs')
    if whiskyEntry.get()!='0':
        textarea.insert(END, f'\nWhisky\t\t\t{whiskyEntry.get()}\t\t\t{whiskyprice} Rs')
    if milkEntry.get()!='0':
        textarea.insert(END, f'\nMilk\t\t\t{milkEntry.get()}\t\t\t{milkprice} Rs')
    textarea.insert(END,'\n-------------------------------------------------------')
    
    if cosmetictaxEntry.get()!='0.0 Rs':
        textarea.insert(END,f'\nCosmetic Tax\t\t\t\t{cosmetictaxEntry.get()}')
    if grocerytaxEntry.get()!='0.0 Rs':
        textarea.insert(END,f'\nGrocery Tax\t\t\t\t{grocerytaxEntry.get()}')
    if drinkstaxEntry.get()!='0.0 Rs':
        textarea.insert(END,f'\nDrinks Tax\t\t\t\t{drinkstaxEntry.get()}')
    textarea.insert(END,f'\n\nTotal Bill \t\t\t\t {totalbill}')
    textarea.insert(END,'\n-------------------------------------------------------')
    save_bill()
        
    

        
        


def total():
    global soapprice,hairsprayprice,hairgelprice,facecreamprice,facewashprice,bodylotionprice
    global riceprice,oilprice,garriprice,wheatprice,yamprice,sugarprice
    global topprice,pepsiprice,spritprice,castelprice,whiskyprice,milkprice
    global totalbill
    #cosmetic price calculation
    soapprice=int(bathsoapEntry.get())*20
    facecreamprice=int(facecreamEntry.get())*50
    facewashprice=int(facewashEntry.get())*100
    hairsprayprice=int(hairsprayEntry.get())*150
    hairgelprice=int(hairgelEntry.get())*80
    bodylotionprice=int(bodylotionEntry.get())*60
    
    totalcosmeticprice=soapprice+facewashprice+facecreamprice+hairsprayprice+hairgelprice+bodylotionprice
    cosmeticpriceEntry.delete(0, END)
    cosmeticpriceEntry.insert(0, f'{totalcosmeticprice} Rs')
    cosmetictax=totalcosmeticprice*0.12
    cosmetictaxEntry.delete(0,END)
    cosmetictaxEntry.insert(0,str(cosmetictax) + ' Rs')
    
    
    #grocery price calculation
    riceprice=int(riceEntry.get())*30
    oilprice=int(oilEntry.get())*100
    garriprice=int(garriEntry.get())*120
    wheatprice=int(wheatEntry.get())*50
    yamprice=int(yamEntry.get())*140
    sugarprice=int(sugarEntry.get())*80
    
    totalgroceryprice=riceprice+oilprice+garriprice+wheatprice+yamprice+sugarprice
    grocerypriceEntry.delete(0,END)
    grocerypriceEntry.insert(0, f'{totalgroceryprice} Rs')
    grocerytax=totalgroceryprice*0.05
    grocerytaxEntry.delete(0,END)
    grocerytaxEntry.insert(0,str(grocerytax) + ' Rs')
    
    
    #drinks price calculation
    topprice = int(topEntry.get()) * 50
    pepsiprice = int(pepsiEntry.get()) * 20
    spritprice = int(spritEntry.get()) * 30
    castelprice = int(castelEntry.get()) * 20
    whiskyprice = int(whiskyEntry.get()) * 45
    milkprice = int(milkEntry.get()) * 90
    
    totaldrinksprice=topprice+pepsiprice+spritprice+castelprice+whiskyprice+milkprice
    drinkspriceEntry.delete(0,END)
    drinkspriceEntry.insert(0, f'{totaldrinksprice} Rs')
    drinkstax=totalgroceryprice*0.08
    drinkstaxEntry.delete(0,END)
    drinkstaxEntry.insert(0,str(drinkstax) + ' Rs')
    
    totalbill=totalcosmeticprice+totalgroceryprice+totaldrinksprice+cosmetictax+grocerytax+drinkstax

#GUI Part

root = Tk()
root.title('Inventory Management System')
root.geometry('1270x684')
headingLable=Label(root, text='Inventary Management System', font=('times new roman', 30, 'bold')
                   ,bg='grey20',fg='gold', bd=12, relief=GROOVE)
headingLable.pack(fill=X)
customer_details_frame=LabelFrame(root, text='Customer Details', font=('times new roman', 14, 'bold'),
                                  fg='gold', bd=8, relief=GROOVE, bg='grey20')
customer_details_frame.pack(fill=X)

nameLable=Label(customer_details_frame, text='Name', font=('times new roman', 14, 'bold'), bg='grey20',
                fg='white')
nameLable.grid(row=0, column=0, padx=20,)

nameEntry=Entry(customer_details_frame, font=('arial', 14), bd=7, width=18)
nameEntry.grid(row=0, column=1, padx=8)

phoneLable=Label(customer_details_frame, text='Phone Number', font=('times new roman', 14, 'bold'), bg='grey20',
                fg='white')
phoneLable.grid(row=0, column=2, padx=20, pady=2)


phoneEntry=Entry(customer_details_frame, font=('arial', 15), bd=7, width=18)
phoneEntry.grid(row=0, column=3, padx=8)

billnumberLable=Label(customer_details_frame, text='Bill Number', font=('times new roman', 14, 'bold'), bg='grey20',
                fg='white')
billnumberLable.grid(row=0, column=4, padx=20, pady=2)

billnumberEntry=Entry(customer_details_frame, font=('arial', 15), bd=7, width=18)
billnumberEntry.grid(row=0, column=5, padx=8)

searchButton=Button(customer_details_frame, text='SEARCH', 
                    font=('arial', 12, 'bold'), bd=7, width=10, command=search_bill)
searchButton.grid(row=0, column=6, padx=20, pady=8)


productsFrame=Frame(root)
productsFrame.pack()

cosmeticsFrame=LabelFrame(productsFrame, text='Cosmetics', font=('times new romans', 14, 'bold'),
                          fg='gold', bd=8, relief=GROOVE, bg='grey20')
cosmeticsFrame.grid(row=0, column=0)

bathsoapLable=Label(cosmeticsFrame, text='Bath Soap', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
bathsoapLable.grid(row=0, column=0, pady=6, padx=10, sticky='w')

bathsoapEntry=Entry(cosmeticsFrame, font=('times new romab', 14, 'bold'),width=10)
bathsoapEntry.grid(row=0, column=1, pady=6, padx=10, sticky='w')
bathsoapEntry.insert(0,0)


facecreamLable=Label(cosmeticsFrame, text='Face Cream', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
facecreamLable.grid(row=1, column=0, pady=6, padx=10, sticky='w')

facecreamEntry=Entry(cosmeticsFrame, font=('times new romab', 14, 'bold'),width=10)
facecreamEntry.grid(row=1, column=1, pady=6, padx=10, sticky='w')
facecreamEntry.insert(0,0)


facewashLable=Label(cosmeticsFrame, text='Face Wash', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
facewashLable.grid(row=2, column=0, pady=6, padx=10, sticky='w')

facewashEntry=Entry(cosmeticsFrame, font=('times new romab', 14, 'bold'),width=10)
facewashEntry.grid(row=2, column=1, pady=6, padx=10, sticky='w')
facewashEntry.insert(0,0)

hairsprayLable=Label(cosmeticsFrame, text='Hair Spray', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
hairsprayLable.grid(row=3, column=0, pady=6, padx=10, sticky='w')

hairsprayEntry=Entry(cosmeticsFrame, font=('times new romab', 14, 'bold'),width=10)
hairsprayEntry.grid(row=3, column=1, pady=6, padx=10, sticky='w')
hairsprayEntry.insert(0,0)

hairgelLable=Label(cosmeticsFrame, text='Hair Gel', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
hairgelLable.grid(row=4, column=0, pady=6, padx=10, sticky='w')

hairgelEntry=Entry(cosmeticsFrame, font=('times new romab', 14, 'bold'),width=10)
hairgelEntry.grid(row=4, column=1, pady=6, padx=10, sticky='w')
hairgelEntry.insert(0,0)

bodylotionLable=Label(cosmeticsFrame, text='Body Lotion', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
bodylotionLable.grid(row=5, column=0, pady=6, padx=10, sticky='w')

bodylotionEntry=Entry(cosmeticsFrame, font=('times new romab', 14, 'bold'),width=10)
bodylotionEntry.grid(row=5, column=1, pady=6, padx=10, sticky='w')
bodylotionEntry.insert(0,0)

groceryFrame=LabelFrame(productsFrame, text='Grocery', font=('times new romans', 14, 'bold'),
                          fg='gold', bd=8, relief=GROOVE, bg='grey20')
groceryFrame.grid(row=0, column=1)


riceLable=Label(groceryFrame, text='Rice', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
riceLable.grid(row=0, column=0, pady=6, padx=10, sticky='w')

riceEntry=Entry(groceryFrame, font=('times new romab', 14, 'bold'),width=10)
riceEntry.grid(row=0, column=1, pady=6, padx=10, sticky='w')
riceEntry.insert(0,0)

oilLable=Label(groceryFrame, text='Oil', font=('times new romans', 15, 'bold'), bg='grey20',
                    fg='white')
oilLable.grid(row=1, column=0, pady=9, padx=10, sticky='w')

oilEntry=Entry(groceryFrame, font=('times new romab', 14, 'bold'),width=10)
oilEntry.grid(row=1, column=1, pady=6, padx=10, sticky='w')
oilEntry.insert(0,0)

garriLable=Label(groceryFrame, text='Garri', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
garriLable.grid(row=2, column=0, pady=6, padx=10, sticky='w')

garriEntry=Entry(groceryFrame, font=('times new romab', 14, 'bold'),width=10)
garriEntry.grid(row=2, column=1, pady=6, padx=10, sticky='w')
garriEntry.insert(0,0)

wheatLable=Label(groceryFrame, text='Wheat', font=('times new romans', 15, 'bold'), bg='grey20',
                    fg='white')
wheatLable.grid(row=3, column=0, pady=6, padx=10, sticky='w')

wheatEntry=Entry(groceryFrame, font=('times new romab', 14, 'bold'),width=10)
wheatEntry.grid(row=3, column=1, pady=6, padx=10, sticky='w')
wheatEntry.insert(0,0)

yamLable=Label(groceryFrame, text='Yam', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
yamLable.grid(row=4, column=0, pady=6, padx=10, sticky='w')

yamEntry=Entry(groceryFrame, font=('times new romab', 14, 'bold'),width=10)
yamEntry.grid(row=4, column=1, pady=6, padx=10, sticky='w')
yamEntry.insert(0,0)

sugarLable=Label(groceryFrame, text='Sugar', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
sugarLable.grid(row=5, column=0, pady=6, padx=10, sticky='w')

sugarEntry=Entry(groceryFrame, font=('times new romab', 14, 'bold'),width=10)
sugarEntry.grid(row=5, column=1, pady=6, padx=10, sticky='w')
sugarEntry.insert(0,0)

drinksFrame=LabelFrame(productsFrame, text='Cold Drinks', font=('times new romans', 15, 'bold'),
                          fg='gold', bd=8, relief=GROOVE, bg='grey20')
drinksFrame.grid(row=0, column=2)


topLable=Label(drinksFrame, text='Top', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
topLable.grid(row=0, column=0, pady=6, padx=10, sticky='w')

topEntry=Entry(drinksFrame, font=('times new romab', 15, 'bold'),width=10)
topEntry.grid(row=0, column=1, pady=6, padx=10, sticky='w')
topEntry.insert(0,0)


pepsiLable=Label(drinksFrame, text='Pepsi', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
pepsiLable.grid(row=1, column=0, pady=6, padx=10, sticky='w')

pepsiEntry=Entry(drinksFrame, font=('times new romab', 14, 'bold'),width=10)
pepsiEntry.grid(row=1, column=1, pady=6, padx=10, sticky='w')
pepsiEntry.insert(0,0)


spritLable=Label(drinksFrame, text='Sprit', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
spritLable.grid(row=2, column=0, pady=6, padx=10, sticky='w')

spritEntry=Entry(drinksFrame, font=('times new romab', 14, 'bold'),width=10)
spritEntry.grid(row=2, column=1, pady=6, padx=10, sticky='w')
spritEntry.insert(0,0)

castelLable=Label(drinksFrame, text='Castel', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
castelLable.grid(row=3, column=0, pady=6, padx=10, sticky='w')

castelEntry=Entry(drinksFrame, font=('times new romab', 15, 'bold'),width=10)
castelEntry.grid(row=3, column=1, pady=6, padx=10, sticky='w')
castelEntry.insert(0,0)

whiskyLable=Label(drinksFrame, text='Whisky', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
whiskyLable.grid(row=4, column=0, pady=6, padx=10, sticky='w')

whiskyEntry=Entry(drinksFrame, font=('times new romab', 14, 'bold'),width=10)
whiskyEntry.grid(row=4, column=1, pady=6, padx=10, sticky='w')
whiskyEntry.insert(0,0)

milkLable=Label(drinksFrame, text='Milk', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
milkLable.grid(row=5, column=0, pady=6, padx=10, sticky='w')

milkEntry=Entry(drinksFrame, font=('times new romab', 14, 'bold'),width=10)
milkEntry.grid(row=5, column=1, pady=6, padx=10, sticky='w')
milkEntry.insert(0,0)


billframe=Frame(productsFrame, bd=8, relief=GROOVE)
billframe.grid(row=0, column=3, padx=10)

billareaLabel=Label(billframe, text='Bill Area', font=('times new romans', 14, 'bold'), bd=7, relief=GROOVE)
billareaLabel.pack(fill=X)

Scrollbar=Scrollbar(billframe, orient=VERTICAL)
Scrollbar.pack(side=RIGHT, fill=Y)

textarea=Text(billframe, height=18, width=55, yscrollcommand=Scrollbar.set)
textarea.pack()
Scrollbar.config(command=textarea.yview)


billmenuFrame=LabelFrame(root, text='Bill Menu', font=('times new romans', 14, 'bold'),
                          fg='gold', bd=8, relief=GROOVE, bg='grey20')
billmenuFrame.pack()


cosmeticpriceLable=Label(billmenuFrame, text='Cosmetic Price', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
cosmeticpriceLable.grid(row=0, column=0, pady=9, padx=10, sticky='w')

cosmeticpriceEntry=Entry(billmenuFrame, font=('times new romab', 14, 'bold'),width=10)
cosmeticpriceEntry.grid(row=0, column=1, pady=6, padx=10)


grocerypriceLable=Label(billmenuFrame, text='Grocery Price', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
grocerypriceLable.grid(row=1, column=0, pady=6, padx=10, sticky='w')

grocerypriceEntry=Entry(billmenuFrame, font=('times new romab', 14, 'bold'),width=10)
grocerypriceEntry.grid(row=1, column=1, pady=6, padx=10)


drinkspriceLable=Label(billmenuFrame, text='Cold Drink Price', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
drinkspriceLable.grid(row=2, column=0, pady=9, padx=10, sticky='w')

drinkspriceEntry=Entry(billmenuFrame, font=('times new romab', 14, 'bold'),width=10)
drinkspriceEntry.grid(row=2, column=1, pady=6, padx=10)


cosmetictaxLable=Label(billmenuFrame, text='Cosmetic Tax', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
cosmetictaxLable.grid(row=0, column=2, pady=6, padx=10, sticky='w')

cosmetictaxEntry=Entry(billmenuFrame, font=('times new romab', 14, 'bold'),width=10, bd=5)
cosmetictaxEntry.grid(row=0, column=3, pady=6, padx=10)


grocerytaxLable=Label(billmenuFrame, text='Grocery Tax', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
grocerytaxLable.grid(row=1, column=2, pady=6, padx=10, sticky='w')

grocerytaxEntry=Entry(billmenuFrame, font=('times new romab', 14, 'bold'),width=10)
grocerytaxEntry.grid(row=1, column=3, pady=6, padx=10)


drinkstaxLable=Label(billmenuFrame, text='Cold Drink Tax', font=('times new romans', 14, 'bold'), bg='grey20',
                    fg='white')
drinkstaxLable.grid(row=2, column=2, pady=9, padx=10, sticky='w')

drinkstaxEntry=Entry(billmenuFrame, font=('times new romab', 14, 'bold'), width=10, bd=5)
drinkstaxEntry.grid(row=2, column=3, pady=6, padx=10)

buttonFrame=Frame(billmenuFrame, bd=8, relief=GROOVE)
buttonFrame.grid(row=0, column=4, rowspan=3)

totalButton=Button(buttonFrame, text='Total', font=('arial', 16, 'bold'), bg='gray20', fg='white'
                   ,bd=5, width=8, pady=10, command=total)
totalButton.grid(row=0, column=0, pady=20, padx=5)


billButton=Button(buttonFrame, text='Bill', font=('arial', 16, 'bold'), bg='gray20', fg='white'
                   ,bd=5, width=8, pady=10, command=bill_area)
billButton.grid(row=0, column=1, pady=20, padx=5)


emailButton=Button(buttonFrame, text='Email', font=('arial', 16, 'bold'), bg='gray20', fg='white'
                   ,bd=5, width=8, pady=10, command=send_email)
emailButton.grid(row=0, column=2, pady=20, padx=5)


printButton=Button(buttonFrame, text='Print', font=('arial', 16, 'bold'), bg='gray20', fg='white'
                   ,bd=5, width=8, pady=10, command=print_bill)
printButton.grid(row=0, column=3, pady=20, padx=5)


clearButton=Button(buttonFrame, text='Clear', font=('arial', 16, 'bold'), bg='gray20', fg='white'
                   ,bd=5, width=8, pady=10,command=clear)
clearButton.grid(row=0, column=4, pady=20, padx=5)







root.mainloop()



""" clear = lambda: os.system('cls')

def main():
    print("INVENTORY MANAGEMENT")
    print("....................")
    print()
    print("Available Options")
    print()
    print("1 - Add Item To Inventory")
    print("2 - View Inventory")
    print()
    while True:
        userChoice = input("Choose an option: ")
        if userChoice == '1':
            addItemsToInventory()
            break
        elif userChoice == '2':
            viewInventory()
            break

def addItemsToInventory():
    clear()
    print("ADD ITEM TO INVENTORY")
    print("......................")
    print()
    print("Available Options:")
    print()
    print("1 - Add Multiple Items")
    print("2 - Add Single Item")
    print()
    while True:
        userChoice = input("Choose an option: ")
        if userChoice in ['1', '2']:
            break
    if userChoice == '1':
        print()
        while True:
            numItems = input("Enter the number of items to be added: ")
            if numItems.isdigit():
                break
        numItems = int(numItems)
        userItems = {}
        for i in range(1, numItems + 1):
            while True:
                print()
                user_item = input("Item Name: ")
                if user_item != '':
                    break
            while True:
                item_amount = input("Item Amount: ")
                if item_amount.isdigit():
                    break
            userItems.update({user_item: int(item_amount)})
        addItemToFile(userItems, clear=False)
        returnToMainMenu("Item(s) have been added")
    elif userChoice == '2':
        print()
        while True:
            user_item = input("Item Name: ")
            if user_item != '':
                break
        while True:
            item_amount = input("Item Amount: ")
            if item_amount.isdigit():
                break
        addItemToFile({user_item: int(item_amount)}, clear=False)
        returnToMainMenu("Item has been added")

def viewInventory():
    clear()
    print("VIEW INVENTORY")
    print("...............")
    print("Press (B) to go back:")
    print()
    invItems = getInvItems()
    print("ITEMS")
    print(".....")
    print()
    for item in invItems:
        print(f"{item}: {invItems[item]}")
    print()
    print("Available Options:")
    print()
    print("1 - Edit Item")
    print("2 - Delete Item")
    print()
    while True:
        userChoice = input("Choose an option: ")
        if userChoice == 'b':
            main()
            break
        elif userChoice == '1':
            editInventoryItem()
            break
        elif userChoice == '2':
            deleteInventoryItem()
            break

def editInventoryItem():
    print()
    clear()
    print("EDIT INVENTORY ITEM")
    print("....................")
    print("Press (B) to go back")
    print()
    print("Available Options:")
    print()
    print("1 - Edit Item Name")
    print("2 - Edit Item Amount")
    print()
    while True:
        userChoice = input("Choose an option: ").lower()
        if userChoice in ['1', '2', 'b']:
            break
    if userChoice == 'b':
        main()
    invItems = getInvItems()
    if userChoice == '1':
        print()
        while True:
            itemToChange = input("Enter the name of the item to be edited: ")
            if itemToChange in invItems:
                break
            else:
                print("That item does not exist")
                print()
        while True:
            newItemName = input("Enter the new item name: ")
            if newItemName != '':
                break
        invItems.update({newItemName: invItems[itemToChange]})
        del invItems[itemToChange]
        addItemToFile(invItems, clear=False)
        returnToMainMenu("Item name has been changed")
    elif userChoice == '2':
        print()
        while True:
            itemToChange = input("Enter the name of the item to edit: ")

    if itemToChange in invItems:
        while True:
            newAmount = input("Enter the new amount: ")
            if newAmount.isdigit():
                break
        invItems.update({itemToChange: int(newAmount)})
        addItemToFile(invItems, clear=False)
        returnToMainMenu("Item amount has been changed")

def deleteInventoryItem():
    print()
    clear()
    print("DELETE INVENTORY ITEM")
    print("......................")
    print("Press (B) to go back")
    print()
    invItems = getInvItems()
    while True:
        itemToDelete = input("Enter the name of the item to delete: ")
        if itemToDelete == 'b':
            main()
        elif itemToDelete not in invItems:
            print("That item does not exist")
            print()
        else:
            break
    del invItems[itemToDelete]
    addItemToFile(invItems, clear=False)
    returnToMainMenu("Item has been deleted")

def getInvItems():
    invItems = {}
    with open('userItem/userItem.txt', 'r') as f:
        for line in f:
            itemName, itemAmount = line.split()
            invItems.update({itemName: int(itemAmount)})
    return invItems

def addItemToFile(items, clear=True):
    with open('userItem/userItem.txt', 'a') as f:
        for item in items:
            f.write(f"{item} {items[item]}\n")
    if clear:
        clear()

def returnToMainMenu(message):
    print()
    print(message)
    print()
    print("Press Enter key to return to Main Menu...")
    input()
    main()

if __name__ == "__main__":
    main() """